public class Calculator_Assignment {
    
  public static double NUM1;
  public static double NUM2;
 
  public static void Sum(){
      double SUM = NUM1+ NUM2;
      System.out.println("The SUM is: " + SUM);
  }
  public static void  Multiply(){
      double MULTIPLY =NUM1*NUM2;
      System.out.println("The multiplication is: " + MULTIPLY);
  }
  public static void Divide() {
      double DIVIDE=NUM1 / NUM2;
      System.out.println("The division is: " + DIVIDE);
  } 
  public static void Modulus (){
      double MODULUS=NUM1 % NUM2;
      System.out.println("The modulus of two numbers is: " + MODULUS);
  } 
    public static void Sin (){
      double SIN1 = Math.sin(NUM1);
       double SIN2=Math.sin(NUM2);
       System.out.println("The Sin of 15 is : "+ SIN1 +"\n"+"The Sin of 5 is : " + SIN2);
    }
    
     public static void Cos(){
      double COS1 = Math.cos(NUM1);
       double COS2=Math.cos(NUM2);
       System.out.println("The Cos of 15 is : "+COS1+"\n"+"The Cos of 5 is : "+COS2);
  } 
  public static void Tan (){
      double TAN1=Math.tan(NUM1);
       double TAN2=Math.tan(NUM2);
       System.out.println("The Tan of 15 is: "+ TAN1 +"\n"+"The Tan of 5 is: "+ TAN2);
  } 
   
 
  
}