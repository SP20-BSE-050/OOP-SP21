/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author 123
 */
public class runnerCalculatorA {
    public static void main(String[] args) {
        
       Calculator_Assignment.NUM1 =15;
       Calculator_Assignment.NUM2 = 5;
       System.out.println("The two numbers are 15(num1) and 5(num2)");
       Calculator_Assignment.Sum();
       Calculator_Assignment.Multiply();
       Calculator_Assignment.Divide();
       Calculator_Assignment.Modulus();
       Calculator_Assignment.Tan();
       Calculator_Assignment.Sin();
       Calculator_Assignment.Cos();
        
    }

}
    

