public class runnerha1 {

    
    public static void main(String[] args) {
        SavingsAccount_HA1 saver1 = new SavingsAccount_HA1(2000.00);
        SavingsAccount_HA1 saver2 = new SavingsAccount_HA1(3000.00);
        System.out.println(" annualInterestRate is 3 percent ");
        saver1.modifyInterestRate(3);
        saver1.MonthlyInterest();
        saver2.MonthlyInterest();
        System.out.println("The SavingBalance for saver1 with 3% interest is: "+saver1.getSavingsB());
        System.out.println("The SavingBalance for saver2 with 3% interest is: "+saver2.getSavingsB());

        
        System.out.println("\nThe annual interest rate is 4%");
        saver2.modifyInterestRate(4);
        saver1.MonthlyInterest();
        saver2.MonthlyInterest();
        System.out.println("The SavingBalance for saver1 with 4% interest is: "+saver1.getSavingsB());
        System.out.println("The SavingBalance for saver2 with 4% interest is: "+saver2.getSavingsB());

    }
}