public class SavingsAccount_HA1 {
    private static double annualInterestRate;
    private double savingsBalance;
    
     public void MonthlyInterest(){
        double x;
        x = savingsBalance * (annualInterestRate/12);
        savingsBalance += x;
    }

    public SavingsAccount_HA1(double savingBalance){
        this.savingsBalance = savingsBalance;
    }

   

    public void modifyInterestRate(double annualInterestRate){
        SavingsAccount_HA1.annualInterestRate = annualInterestRate;
    }

    public double getSavingsB(){
        return savingsBalance;
    }
}