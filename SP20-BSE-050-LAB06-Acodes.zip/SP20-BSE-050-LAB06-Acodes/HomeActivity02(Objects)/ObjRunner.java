public class ObjRunner {
    public static void main(String[] args) {
        CountObjectsCreated Obj1 = new CountObjectsCreated();
        CountObjectsCreated Obj2 = new CountObjectsCreated(10);
        CountObjectsCreated Obj3 = new CountObjectsCreated(13);

        System.out.println("Total number of objects created are: " + Obj1.Total_Obj());

    }
}