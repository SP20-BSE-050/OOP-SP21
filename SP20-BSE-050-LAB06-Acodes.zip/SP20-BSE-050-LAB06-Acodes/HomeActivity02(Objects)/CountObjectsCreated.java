public class CountObjectsCreated {

    private static int countObj = 0;
    private static int d;
    public CountObjectsCreated(){
        countObj++;

    }
    public CountObjectsCreated(int obj){
        d = obj;
        countObj++;
    }
    public static int Total_Obj() {
        return countObj;

    }
    }
