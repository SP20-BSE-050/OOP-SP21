/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_a01;

/**
 *
 * @author 123
 */
public class hotdogstand_runner {
    public static void main(String[] args) {
		hotdogstand j1=new hotdogstand(12,16);
        j1.justsold();
        j1.DISPLAY();
        
        hotdogstand j2=new hotdogstand(15,16);
        j2.justsold();
        j2.DISPLAY();
        
        hotdogstand j3=new hotdogstand(1,16);
        j3.justsold();
        j3.DISPLAY();
	}
    
}
