/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_a01;

/**
 *
 * @author 123
 */
public class hotdogstand {

    private int ID_num;
	private int hotdog_sold;
	


        public hotdogstand() {
        
    	ID_num=00;
    	hotdog_sold=00;
    }
    
    public hotdogstand(int i,int s) {
    	ID_num = i;
    	hotdog_sold = s;
    	
    }
    public void justsold() {
    	hotdog_sold++;
    }
    
    public void DISPLAY() {
    	System.out.println("ID number of stands: " + ID_num + "\nNumber of hotdogs sold: " + hotdog_sold);
    }

}
  
    

