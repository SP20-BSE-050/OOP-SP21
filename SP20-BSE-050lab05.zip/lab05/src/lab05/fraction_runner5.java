/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab05;

/**
 *
 * @author 123
 */
public class fraction_runner5 {
    
    public static void main(String[] args){
        fraction_lab05 frac_1 = new fraction_lab05();
        fraction_lab05 frac_2 = new fraction_lab05();
        frac_2.setValueOfX(32);
        frac_2.setValueOfY(4);
        frac_1.display();
        frac_2.display();
        System.out.println("Identical Ratios= "+frac_1.equals(frac_1,frac_2));
        }
}
    

