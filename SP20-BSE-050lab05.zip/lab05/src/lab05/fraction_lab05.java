/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab05;

/**
 *
 * @author 123
 */
public class fraction_lab05 {
    private int x;
    private int y;
    private int z;
    public fraction_lab05(){
        x = 8;
        y = 2;
    }
    public fraction_lab05(int x, int y){
        this.x = y;
        this.x = y;
    }
    public void setValueOfX(int x){
        this.x = x;
    }
    public void setValueOfY(int y){
        this.y = y;
    }
    public int getValueOfX(){
        return x;
    }
    public int getValueOfY(){
        return y;
    }
    public boolean equals(fraction_lab05 frac_1, fraction_lab05 frac_2){
        if(frac_1 == frac_2)
            return true;
        else
            return false;
    }
    public void display(){
        System.out.println("Ratio is = "+x/y);
    }
    
}
    

